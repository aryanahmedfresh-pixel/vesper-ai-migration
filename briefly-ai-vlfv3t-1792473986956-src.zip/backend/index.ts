import { router, json, error, ai } from '@appdeploy/sdk';

type ChatMessage = { role: 'user' | 'assistant'; content: string };
type UploadedText = { name: string; type: string; content: string };
type UploadedImage = { name: string; data: string; mimeType: string };
type SearchRequest = {
  query?: string;
  systemPrompt?: string;
  ageGroup?: string;
  history?: ChatMessage[];
  searchWeb?: boolean;
  thinkMode?: boolean;
  files?: UploadedText[];
  images?: UploadedImage[];
};

function extractSources(text: string) {
  const found = new Map<string, { title: string; url: string; snippet: string }>();
  const linked = /\[([^\]]{3,180})\]\((https?:\/\/[^\s)]+)\)/g;
  const plain = /(https?:\/\/(?:www\.)?[^\s<>"]+)/g;
  for (const match of text.matchAll(linked)) {
    const title = match[1].trim();
    const url = match[2].replace(/[),.;]+$/, '');
    if (!found.has(url) && !url.includes('google.com/search') && !url.includes('bing.com/search')) found.set(url, { title, url, snippet: '' });
  }
  for (const match of text.matchAll(plain)) {
    const url = match[1].replace(/[),.;]+$/, '');
    if (!found.has(url) && !url.includes('google.com/search') && !url.includes('bing.com/search')) found.set(url, { title: url.replace(/^https?:\/\//, '').slice(0, 100), url, snippet: '' });
  }
  return [...found.values()].slice(0, 6);
}

function formatPlainTextAnswer(input: string): string {
  return input
    // Convert common LaTeX fractions to readable plain-text fractions.
    .replace(/\\(?:d?frac)\s*\{([^{}]+)\}\s*\{([^{}]+)\}/g, '($1)/($2)')
    .replace(/\/frac\/?\s*\{([^{}]+)\}\s*\{([^{}]+)\}/gi, '($1)/($2)')
    .replace(/\\sqrt\s*\{([^{}]+)\}/g, 'sqrt($1)')
    .replace(/\\times\b/g, '×')
    .replace(/\\cdot\b/g, '×')
    .replace(/\\div\b/g, '÷')
    .replace(/\\pm\b/g, '±')
    .replace(/\\leq\b/g, '≤')
    .replace(/\\geq\b/g, '≥')
    .replace(/\\neq\b/g, '≠')
    .replace(/\\left\b|\\right\b/g, '')
    .replace(/\\(?:text|mathrm)\s*\{([^{}]*)\}/g, '$1')
    .replace(/\\\[|\\\]|\\\(|\\\)/g, '')
    .replace(/\$\$?/g, '')
    .replace(/[ \t]+\n/g, '\n')
    .trim();
}

export const handler = router({
  'GET /api/health': [async () => json({ ok: true })],
  'POST /api/search': [
    async ({ body }) => {
      const input = (body || {}) as SearchRequest;
      const query = typeof input.query === 'string' ? input.query.trim().slice(0, 500) : '';
      const systemPrompt = typeof input.systemPrompt === 'string' ? input.systemPrompt.trim().slice(0, 6000) : '';
      const ageGroup = input.ageGroup === '10-12' || input.ageGroup === '18+' ? input.ageGroup : '13-17';
      const agePolicy = ageGroup === '10-12'
        ? 'AGE-APPROPRIATE RESPONSE RULES: The selected audience is ages 10-12. Use simple, supportive, age-appropriate language. Avoid explicit sexual content, graphic violence, instructions for dangerous acts, and content that encourages self-harm or illegal activity. For sensitive health or safety questions, give brief factual education and encourage involving a trusted adult when appropriate. Be kind and never shame the user.'
        : ageGroup === '13-17'
          ? 'AGE-APPROPRIATE RESPONSE RULES: The selected audience is ages 13-17. Be respectful, empathetic, and direct. Sensitive topics such as puberty, relationships, emotions, and health may be addressed with factual, non-graphic, age-appropriate information. Do not provide explicit sexual content involving minors, exploitative content, or instructions that facilitate dangerous acts or self-harm. Encourage trusted adult or professional support when appropriate. Never shame the user.'
          : 'ADULT-AUDIENCE RESPONSE RULES: The selected audience is 18+. Discuss mature topics in a factual, respectful manner when appropriate, but do not provide exploitative sexual content, sexual content involving minors, or instructions that facilitate serious harm, self-harm, violence, or illegal activity. The age setting does not remove baseline safety limits.';
      const searchWeb = input.searchWeb === true;
      const thinkMode = input.thinkMode === true;
      const history = Array.isArray(input.history)
        ? input.history.filter((item): item is ChatMessage => !!item && (item.role === 'user' || item.role === 'assistant') && typeof item.content === 'string')
            .slice(-12).map(item => ({ role: item.role, content: item.content.slice(0, 3000) }))
        : [];
      const files = Array.isArray(input.files) ? input.files.slice(0, 5).filter(file => file && typeof file.name === 'string' && typeof file.content === 'string')
        .map(file => ({ name: file.name.slice(0, 180), type: String(file.type || 'unknown').slice(0, 100), content: file.content.slice(0, 60000) })) : [];
      const images = Array.isArray(input.images) ? input.images.slice(0, 5).filter(image => image && typeof image.data === 'string' && typeof image.mimeType === 'string')
        .map(image => ({ data: image.data.slice(0, 8500000), mimeType: image.mimeType.slice(0, 100) })) : [];
      if (!query && files.length === 0 && images.length === 0) return error('Please enter a message or attach a file.', 400);
      if (/^(hi|hello|hey|hiya|howdy|good morning|good afternoon|good evening|greetings)[!.\\s👋😊]*$/i.test(query) && files.length === 0 && images.length === 0) {
        return json({ answer: "Hello 👋 boss what's the question or task ?", sources: [] });
      }

      const tools = searchWeb ? [{
        name: 'search_web',
        description: 'Search the public web for pages relevant to the user request. Call this before answering when current facts or sources are needed.',
        parameters: { type: 'object', properties: { query: { type: 'string', description: 'Search terms for web search' } }, required: ['query'], additionalProperties: false },
      }] : [];

      const fileContext = files.length ? '\n\nATTACHED FILES:\n' + files.map(file => 'File: ' + file.name + ' (' + file.type + ')\n' + file.content).join('\n\n').slice(0, 90000) : '';
      const imageNames = Array.isArray(input.images) ? input.images.slice(0, 5).map((image, index) => 'Image ' + (index + 1) + ': ' + String(image.name || 'attached image').slice(0, 180)).join('\n') : '';
      const prompt = (searchWeb
        ? 'Answer the user request using web search. Search for current, relevant results, then summarize useful findings. Distinguish facts from uncertainty, do not invent sources, and include useful source URLs when available. Keep the answer clear and helpful. Current user request: '
        : 'Answer the user request directly and helpfully using your existing knowledge. Be clear about uncertainty and do not claim to have searched the web. For all mathematics and school sums, respond in clean plain text that can be copied into a .txt file. Never output raw LaTeX or markup such as \\frac, /frac/, \\(, \\), or dollar-delimited equations. Write fractions as (numerator)/(denominator), powers as x^2, multiplication as × or *, and division as ÷ or /. Show each calculation step on its own line and clearly label the final answer. Current user request: ') + (query || 'Please inspect and analyze the attachments.') + fileContext + (imageNames ? '\n\n' + imageNames : '');

      try {
        const result = await ai.run({
          prompt,
          system: [systemPrompt, agePolicy].filter(Boolean).join('\n\n'),
          ...(history.length ? { messages: [...history, { role: 'user' as const, content: (query || 'Please inspect and analyze the attachments.') + fileContext }] } : {}),
          ...(images.length ? { images: images.map(({ data, mimeType }) => ({ data, mimeType })) } : {}),
          ...(tools.length ? { tools } : {}),
          ...(searchWeb ? {
            onToolCall: async (name: string, args: Record<string, unknown>) => {
              if (name !== 'search_web') return { error: 'Unknown tool' };
              const searchQuery = typeof args.query === 'string' ? args.query.slice(0, 350) : query;
              const urls = ['https://www.google.com/search?q=' + encodeURIComponent(searchQuery), 'https://www.bing.com/search?q=' + encodeURIComponent(searchQuery)];
              const results: { engine: string; title?: string; text: string; status: number; url: string }[] = [];
              for (const url of urls) {
                try {
                  const page = await ai.scrape({ url });
                  if (page.status < 400 && page.text) results.push({ engine: url.includes('google.com') ? 'Google' : 'Bing', title: page.title, text: page.text.slice(0, 9000), status: page.status, url });
                } catch (e) { console.warn('Search engine fetch failed', url, e); }
              }
              if (!results.length) return { error: 'Search engines could not be reached. Do not pretend a web search succeeded.', query: searchQuery };
              return { query: searchQuery, results };
            },
          } : {}),
          maxSteps: searchWeb ? 3 : 1,
          maxTokens: thinkMode ? 2500 : 1400,
          temperature: 0.2,
          thinkingMode: thinkMode ? 'DEEP' : 'FAST',
        });
        const answer = formatPlainTextAnswer((result.text || '').trim());
        if (!answer) return error('No answer was returned. Please try again.', 502);
        return json({ answer, sources: searchWeb ? extractSources(answer) : [] });
      } catch (err) {
        console.error('Chat request failed', err);
        return error(searchWeb ? 'Web search failed. Please try again.' : 'The assistant could not complete this request. Please try again.', 502);
      }
    },
  ],
});
