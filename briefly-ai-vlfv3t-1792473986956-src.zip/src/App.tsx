import { useEffect, useRef, useState } from 'react';
import { api, image } from '@appdeploy/client';
import {
  Sparkles, SlidersHorizontal, ExternalLink, LoaderCircle, RotateCcw,
  Send, BrainCircuit, Globe, Plus, Copy, Menu, X, Bot, User,
  Paperclip, Camera, ImagePlus, FileText, Trash2,
} from 'lucide-react';

type Source = { title?: string; url?: string; snippet?: string };
type Attachment = { id: string; file: File; preview?: string };
type Message = { role: 'user' | 'assistant'; content: string; sources?: Source[]; attachments?: { name: string; type: string }[] };
type Result = { answer: string; sources: Source[] };
type AgeGroup = '10-12' | '13-17' | '18+';

const defaultPrompt = `You are an advanced, highly capable AI assistant. Your primary objective is to provide accurate, comprehensive, and direct information. You are optimized for technical tasks, coding, research, and complex problem-solving.

DIRECTIVES
1. Be direct and objective. Avoid unnecessary filler.
2. For code requests, provide complete, ready-to-use code.
3. Use precise technical terminology where appropriate.
4. Be honest about uncertainty and never invent sources.
5. Avoid unnecessary warnings for benign tasks.

GREETING BEHAVIOR
If the user only greets you (for example: hello, hi, hey, good morning) without asking a substantive question, reply exactly: Hello 👋 boss what's the question or task ?
If a greeting includes a question or task, answer the task normally.`;

const allowedExtensions = '.dex,.docx,.docs,.sh,.so,.txt,.md,.json,.xml,.java,.kt,.py,.js,.ts,.tsx,.jsx,.html,.css,.c,.cpp,.h,.pdf,.zip,.log,.yaml,.yml,.toml,.gradle,.properties';

export default function App() {
  const [query, setQuery] = useState('');
  const [systemPrompt, setSystemPrompt] = useState(defaultPrompt);
  const [ageGroup, setAgeGroup] = useState<AgeGroup>('13-17');
  const [showSettings, setShowSettings] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [thinkMode, setThinkMode] = useState(false);
  const [searchMode, setSearchMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [attachMenuOpen, setAttachMenuOpen] = useState(false);
  const endRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const imageInputRef = useRef<HTMLInputElement | null>(null);
  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages, loading]);

  function addFiles(list: FileList | null) {
    if (!list) return;
    const incoming = Array.from(list);
    const oversized = incoming.find(file => file.size > 8 * 1024 * 1024);
    if (oversized) {
      setError('Each attachment must be 8 MB or smaller.');
      return;
    }
    setError('');
    setAttachments(current => {
      const remaining = Math.max(0, 5 - current.length);
      const next = incoming.slice(0, remaining).map(file => ({
        id: `${file.name}-${file.size}-${file.lastModified}-${Math.random().toString(36).slice(2, 8)}`,
        file,
        preview: file.type.startsWith('image/') ? URL.createObjectURL(file) : undefined,
      }));
      return [...current, ...next];
    });
  }

  function removeAttachment(id: string) {
    setAttachments(current => {
      const target = current.find(item => item.id === id);
      if (target?.preview) URL.revokeObjectURL(target.preview);
      return current.filter(item => item.id !== id);
    });
  }

  async function sendMessage(event?: React.FormEvent) {
    event?.preventDefault();
    const text = query.trim();
    if ((!text && attachments.length === 0) || loading) {
      if (!text && attachments.length === 0) setError('Type a message or attach a file first.');
      return;
    }
    setError('');
    setQuery('');
    setAttachMenuOpen(false);
    const currentAttachments = attachments;
    const attachmentLabels = currentAttachments.map(item => ({ name: item.file.name, type: item.file.type || 'unknown' }));
    const priorMessages = messages.map(({ role, content }) => ({ role, content }));
    const visibleText = text || 'Please analyze the attached file(s).';
    setMessages(current => [...current, { role: 'user', content: visibleText, attachments: attachmentLabels }]);
    setAttachments([]);
    setLoading(true);
    try {
      const preparedImages: { name: string; data: string; mimeType: string }[] = [];
      const fileTexts: { name: string; type: string; content: string }[] = [];
      for (const item of currentAttachments) {
        if (item.file.type.startsWith('image/')) {
          const prepared = await image.resizeIfNeeded(item.file);
          preparedImages.push({ name: item.file.name, data: prepared.data, mimeType: prepared.mimeType });
        } else if (/\.(txt|sh|md|json|xml|java|kt|py|js|ts|tsx|jsx|html|css|c|cpp|h|log|yaml|yml|toml|gradle|properties)$/i.test(item.file.name) || item.file.type.startsWith('text/')) {
          const content = await item.file.text();
          fileTexts.push({ name: item.file.name, type: item.file.type || 'text/plain', content: content.slice(0, 60000) });
        } else if (/\.(dex|so)$/i.test(item.file.name)) {
          const bytes = new Uint8Array(await item.file.arrayBuffer());
          let printable = '';
          let run = '';
          for (const byte of bytes) {
            if (byte >= 32 && byte <= 126) run += String.fromCharCode(byte);
            else { if (run.length >= 5) printable += run + '\n'; run = ''; }
            if (printable.length > 40000) break;
          }
          if (run.length >= 5 && printable.length < 40000) printable += run;
          fileTexts.push({ name: item.file.name, type: item.file.type || 'application/octet-stream', content: 'Binary file attached. Printable embedded strings extracted for review (not a full disassembly):\n' + printable });
        } else {
          fileTexts.push({ name: item.file.name, type: item.file.type || 'application/octet-stream', content: 'File attached; this format is not decoded by the chat uploader. Analyze only the supplied filename/type and ask for a converted text export if contents are needed.' });
        }
      }
      const response = await api.post('/api/search', {
        query: visibleText,
        systemPrompt,
        ageGroup,
        history: priorMessages,
        searchWeb: searchMode,
        thinkMode,
        images: preparedImages,
        files: fileTexts,
      });
      const data = response.data as Result;
      setMessages(current => [...current, {
        role: 'assistant',
        content: data.answer || 'I couldn’t generate a response. Please try again.',
        sources: Array.isArray(data.sources) ? data.sources : [],
      }]);
    } catch {
      setError('I couldn’t complete that request. Check attachment size/type and try again.');
    } finally {
      currentAttachments.forEach(item => { if (item.preview) URL.revokeObjectURL(item.preview); });
      setLoading(false);
      inputRef.current?.focus();
    }
  }

  function newChat() {
    setMessages([]);
    setQuery('');
    setError('');
    attachments.forEach(item => { if (item.preview) URL.revokeObjectURL(item.preview); });
    setAttachments([]);
    setSidebarOpen(false);
    inputRef.current?.focus();
  }

  return (
    <main className={`chat-shell ${sidebarOpen ? 'sidebar-visible' : ''}`}>
      <aside className="chat-sidebar">
        <div className="sidebar-brand">
          <span className="brand-mark"><Sparkles size={19} /></span>
          <span>VESPER <span className="brand-ai">AI</span></span>
          <button className="icon-button sidebar-close" aria-label="Close menu" onClick={() => setSidebarOpen(false)}><X size={18} /></button>
        </div>
        <button className="new-chat-button" onClick={newChat}><Plus size={17} /> New chat</button>
        <div className="sidebar-caption">YOUR SPACE</div>
        <button className="sidebar-item active" onClick={newChat}><MessageIcon /> Current conversation</button>
        <div className="sidebar-spacer" />
        <div className="sidebar-tagline">Knowledge is power.</div>
        <button className="sidebar-settings" onClick={() => setShowSettings(v => !v)}><SlidersHorizontal size={16} /> Settings</button>
      </aside>
      <section className="chat-main">
        <header className="chat-topbar">
          <button className="icon-button menu-button" aria-label="Open menu" onClick={() => setSidebarOpen(true)}><Menu size={20} /></button>
          <div className="mobile-brand"><span className="brand-mark"><Sparkles size={17} /></span><b>VESPER <span className="brand-ai">AI</span></b></div>
          <div className="model-label"><span className="model-dot" /> VESPER AI <span className="model-version">· Smart chat</span></div>
          <button className="icon-button" aria-label="Settings" onClick={() => setShowSettings(v => !v)}><SlidersHorizontal size={18} /></button>
        </header>

        <div className={`conversation ${messages.length === 0 ? 'conversation-empty' : ''}`}>
          {messages.length === 0 ? (
            <div className="welcome-panel">
              <div className="welcome-icon"><Sparkles size={25} /></div>
              <p className="welcome-eyebrow">YOUR AI WORKSPACE</p>
              <h1>What can I help with?</h1>
              <p className="welcome-subtitle">Knowledge is power.</p>
              <div className="prompt-suggestions">
                {[
                  ['Explain a concept', 'Explain quantum computing in simple terms'],
                  ['Help me code', 'Help me debug a Python function'],
                  ['Research a topic', 'What are the latest advances in space exploration?'],
                ].map(([title, suggestion]) => (
                  <button key={title} onClick={() => { setQuery(suggestion); inputRef.current?.focus(); }}>
                    <strong>{title}</strong><span>{suggestion}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="message-list">
              {messages.map((message, index) => (
                <article className={`message-row ${message.role}`} key={index}>
                  <div className={`message-avatar ${message.role}`}>{message.role === 'assistant' ? <Sparkles size={16} /> : <User size={16} />}</div>
                  <div className="message-body">
                    <div className="message-author">{message.role === 'assistant' ? 'VESPER AI' : 'You'}</div>
                    {message.attachments?.length ? <div className="message-attachment-labels">{message.attachments.map(file => <span key={file.name}><FileText size={13} /> {file.name}</span>)}</div> : null}
                    <div className="message-content">{message.content}</div>
                    {message.sources && message.sources.length > 0 && (
                      <div className="message-sources">
                        <div className="sources-title"><Globe size={14} /> Sources</div>
                        {message.sources.map((source, i) => (
                          <a className="source-chip" key={source.url || i} href={source.url} target="_blank" rel="noreferrer">
                            <span>{source.title || source.url || 'Web source'}</span><ExternalLink size={13} />
                          </a>
                        ))}
                      </div>
                    )}
                    {message.role === 'assistant' && <button className="copy-message" onClick={() => navigator.clipboard?.writeText(message.content).catch(() => {})}><Copy size={13} /> Copy</button>}
                  </div>
                </article>
              ))}
              {loading && <div className="message-row assistant"><div className="message-avatar assistant"><Sparkles size={16} /></div><div className="message-body"><div className="message-author">VESPER AI</div><div className="thinking-indicator"><LoaderCircle className="spin" size={16} /> {thinkMode ? 'Thinking through your request…' : searchMode ? 'Searching and preparing an answer…' : 'Working on your answer…'}</div></div></div>}
              <div ref={endRef} />
            </div>
          )}
        </div>

        {showSettings && (
          <section className="settings-panel chat-settings">
            <div className="settings-title"><strong>Response age group</strong><span>AGE-AWARE</span></div>
            <p>Choose the intended audience. This is a self-selected preference, not age verification. Safety limits still apply to every age group.</p>
            <label className="age-group-label" htmlFor="age-group">Intended audience</label>
            <select id="age-group" className="age-group-select" value={ageGroup} onChange={e => setAgeGroup(e.target.value as AgeGroup)}>
              <option value="10-12">Ages 10–12 · extra protective</option>
              <option value="13-17">Ages 13–17 · teen-appropriate</option>
              <option value="18+">Ages 18+ · adult-appropriate</option>
            </select>
            <div className="settings-title"><strong>System prompt</strong><span>EDITABLE</span></div>
            <p>Customize the assistant’s tone and instructions. Age-appropriate safety rules are applied separately and cannot be overridden here.</p>
            <textarea value={systemPrompt} onChange={e => setSystemPrompt(e.target.value)} rows={7} aria-label="System prompt" />
            <div className="settings-actions"><button className="clear-button" onClick={() => setSystemPrompt('')}><RotateCcw size={14} /> Clear prompt</button><button className="restore-button" onClick={() => setSystemPrompt(defaultPrompt)}>Restore default</button></div>
          </section>
        )}
        {error && <div className="chat-error" role="alert">{error}</div>}

        <div className="composer-area">
          <form className="composer" onSubmit={sendMessage}>
            {attachments.length > 0 && <div className="attachment-preview-list">
              {attachments.map(item => <div className="attachment-preview" key={item.id}>
                {item.preview ? <img src={item.preview} alt={item.file.name} /> : <FileText size={20} />}
                <span title={item.file.name}>{item.file.name}</span>
                <button type="button" aria-label={`Remove ${item.file.name}`} onClick={() => removeAttachment(item.id)}><X size={14} /></button>
              </div>)}
            </div>}
            <textarea
              ref={inputRef}
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void sendMessage(); } }}
              placeholder="Message VESPER AI…"
              rows={1}
              aria-label="Message"
            />
            <div className="composer-toolbar">
              <div className="mode-buttons">
                <div className="attach-menu-wrap">
                  <button type="button" className={`mode-button ${attachMenuOpen ? 'selected' : ''}`} aria-expanded={attachMenuOpen} onClick={() => setAttachMenuOpen(v => !v)}><Paperclip size={15} /> Attach</button>
                  {attachMenuOpen && <div className="attach-menu">
                    <button type="button" onClick={() => { setAttachMenuOpen(false); imageInputRef.current?.click(); }}><ImagePlus size={17} /><span><strong>Photo</strong><small>Choose an image</small></span></button>
                    <button type="button" onClick={() => { setAttachMenuOpen(false); cameraInputRef.current?.click(); }}><Camera size={17} /><span><strong>From camera</strong><small>Take a photo</small></span></button>
                    <button type="button" onClick={() => { setAttachMenuOpen(false); fileInputRef.current?.click(); }}><FileText size={17} /><span><strong>File</strong><small>Documents, code and more</small></span></button>
                  </div>}
                </div>
                <button type="button" className={`mode-button ${thinkMode ? 'selected' : ''}`} aria-pressed={thinkMode} onClick={() => setThinkMode(v => !v)}><BrainCircuit size={15} /> Think</button>
                <button type="button" className={`mode-button ${searchMode ? 'selected' : ''}`} aria-pressed={searchMode} onClick={() => setSearchMode(v => !v)}><Globe size={15} /> Search</button>
                <span className="deploy-credit-indicator" title="AppDeploy account balance snapshot checked on October 20, 2026. This is not a live balance and may have changed." aria-label="AppDeploy deployment credits: 886.16 remaining, last checked October 20, 2026">Credits <strong>886.16</strong> left <span className="credit-snapshot-dot" aria-hidden="true" /></span>
              </div>
              <button className="send-button" type="submit" disabled={loading || (!query.trim() && attachments.length === 0)} aria-label="Send message">
                {loading ? <LoaderCircle className="spin" size={17} /> : <Send size={17} />} <span>Send</span>
              </button>
            </div>
            <input ref={imageInputRef} className="hidden-file-input" type="file" accept="image/*" multiple onChange={e => { addFiles(e.target.files); e.currentTarget.value = ''; }} />
            <input ref={cameraInputRef} className="hidden-file-input" type="file" accept="image/*" capture="environment" onChange={e => { addFiles(e.target.files); e.currentTarget.value = ''; }} />
            <input ref={fileInputRef} className="hidden-file-input" type="file" accept={allowedExtensions + ',*/*'} multiple onChange={e => { addFiles(e.target.files); e.currentTarget.value = ''; }} />
          </form>
          <p className="composer-note">Up to 5 attachments · 8 MB each · Knowledge is power.</p>
        </div>
      </section>
    </main>
  );
}

function MessageIcon() {
  return <Bot size={16} />;
}
